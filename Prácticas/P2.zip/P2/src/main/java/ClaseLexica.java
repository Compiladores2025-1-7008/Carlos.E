package main.java;

public enum ClaseLexica {
    ID,NUMERO,IF,INT,WHILE,ELSE,FLOAT,COMA,LPAR,RPAR,PYC
}